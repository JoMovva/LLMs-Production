# Appendix E: Parameter-efficient Finetuning with LoRA

- [01_main-chapter-code](01_main-chapter-code) contains the main chapter code.