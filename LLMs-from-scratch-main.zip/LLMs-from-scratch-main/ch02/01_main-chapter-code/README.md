# Chapter 2: Working with Text Data

### Main Chapter Code

- [ch02.ipynb](ch02.ipynb) contains all the code as it appears in the chapter

### Optional Code

- [dataloader.ipynb](dataloader.ipynb) is a minimal notebook with the main data loading pipeline implemented in this chapter
