# Byte Pair Encoding (BPE) Tokenizer From Scratch

- [bpe-from-scratch.ipynb](bpe-from-scratch.ipynb) contains optional (bonus) code that explains and shows how the BPE tokenizer works under the hood.
