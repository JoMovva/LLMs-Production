# Appendix A: Introduction to PyTorch

&nbsp;
## Main Chapter Code

- [01_main-chapter-code](01_main-chapter-code) contains the main chapter code

&nbsp;
## Bonus Materials

- [02_setup-recommendations](02_setup-recommendations) contains Python installation and setup recommendations.