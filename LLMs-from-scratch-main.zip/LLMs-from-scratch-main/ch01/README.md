# Chapter 1: Understanding Large Language Models


&nbsp;
## Main Chapter Code

There is no code in this chapter.


&nbsp;
## Bonus Materials

In the video below, I share my personal approach to setting up a Python environment on my computer:

<br>
<br>

[![Link to the video](https://img.youtube.com/vi/yAcWnfsZhzo/0.jpg)](https://www.youtube.com/watch?v=yAcWnfsZhzo)

<br>
<br>

As an optional bonus, the following video tutorial provides an overview of the LLM development lifecycle covered in this book:

<br>
<br>

[![Link to the video](https://img.youtube.com/vi/kPGTx4wcm_w/0.jpg)](https://www.youtube.com/watch?v=kPGTx4wcm_w)

